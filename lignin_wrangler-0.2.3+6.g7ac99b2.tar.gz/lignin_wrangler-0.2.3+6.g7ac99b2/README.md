lignin_wrangler
==============================

This project in progress will (eventually) perform two major functions:
- Read in lignin molecules (from RDKit json files and SMILES, at the minimum) and preform different types of chemistry
    - Reactive catalytic fractionation (RCF)
    - Hydrodeoxygenation (HDO)
    - Fragmentation and rearrangement during mass spectrometry (MS)
- Read in MS output and assign likely molecular formulas to peaks

These two functions are related in that the first will generate dictionaries of molecules that might be observed during 
MS of lignin samples, thus aiding sample analysis as well as helping validate proposed reaction mechanisms in the 
decomposition of lignin. 


## Installation

- For users with no Python experience, a helpful guide to installing Python via miniconda or anaconda can be found 
[here](https://conda.io/docs/user-guide/install/index.html). 

- Once Python has been installed, you will need install [RDKit](https://www.rdkit.org/docs/Install.html) using conda. 
  -  To install it in a new environment, run: `conda create -c rdkit -n lignin-wrangler rdkit`, followed by 
     `conda activate lignin-kmc` 
  -  If you already have a conda environment created and want to add rdkit to that environment, instead run: 
     `conda install -c conda-forge rdkit`

-  In either case, Conda will install any missing required dependencies when it does so, and thus this may take a few 
 minutes.
 
When this package is ready to be released to the public, it will be posted to [pypi](https://pypi.org/) which 
will allow quick installation using pip (e.g. `pip install lignin-wrangler`). Additional dependencies will again be 
installed as required.

Until then, the package can be built and installed with these steps (after installing python and RDKit as noted above):
- clone the repo (e.g. `git clone https://gitlab.com/hmayes/lignin-wrangler.git`)
- run `python setup.py sdist`
- `pip install dist/lignin-wrangler*tar.gz` (clearly, update the * if there are multiple versions in the folder)


## Framework

This project runs on Python ≥3.5 with the following packages:
- rdKit (>= 2018.03.4.0; must be installed via conda; see above)
- common-wrangler (common_wrangler >= 0.2.6)
- pymzml

### References

Isotopic compositions and masses were downloaded on 2019-10-29 from 
[NIST](https://www.nist.gov/pml/atomic-weights-and-isotopic-compositions-relative-atomic-masses?iframe=true&width=100%2525252525&height=100%2525252525)


### Copyright

Copyright (c) 2019-2020, Heather Mayes
 
#### Acknowledgements
 
Project based on the 
[Computational Chemistry Python Cookiecutter](https://github.com/choderalab/cookiecutter-python-comp-chem)
