# -*- coding: utf-8 -*-

"""
ms_plotting.py
Methods called by ms2molecules to plot MS output
"""

import os
from collections import defaultdict

import matplotlib.pyplot as plt
import numpy as np
from common_wrangler.common import (create_out_fname, make_fig, InvalidDataError, warning)

plt.style.use('seaborn-whitegrid')


def gen_total_intensity_plot(fname, data_array_dict, num_decimals_ret_time_accuracy, out_dir):
    """
    Plot total intensity versus retention times (combines retention times in this method; calls plotting function)
    :param fname: str, name of the file where the data originated
    :param data_array_dict: dict of ms_level (keys) and their ndarrays (n x 3) with M/Z, intensity, and retention times
    :param num_decimals_ret_time_accuracy: number of decimal points in retention time accuracy, for rounding
    :param out_dir: None or str, provides location where new file should be saved (None for current directory)
    :return: ndarray, (m x 2), were m is the number of unique retention times, in first column. Second column is
        total intensity for that retention time.
    """
    for ms_level, data_array in data_array_dict.items():
        # in case not already rounded and sorted...
        data_array[:, 2] = np.around(data_array[:, 2], num_decimals_ret_time_accuracy)
        # the intensity and mz order does not matter, only ret time
        data_array = data_array[data_array[:, 2].argsort()]
        unique_ret_times = np.unique(data_array[:, 2])
        total_intensities = np.full((len(unique_ret_times)), np.nan)
        for ret_index, ret_time in enumerate(unique_ret_times):
            unique_ret_time_data_array = data_array[data_array[:, 2] == ret_time]
            total_intensities[ret_index] = np.sum(unique_ret_time_data_array[:, 1])

        x_label = "Retention time (min)"
        y_label = "Total intensity (unscaled)"
        suffix = "_tot_int"
        if ms_level not in fname:
            suffix = suffix + "_" + ms_level
        plot_fname = create_out_fname(fname, suffix=suffix, ext='png', base_dir=out_dir)
        make_fig(plot_fname, unique_ret_times, total_intensities, x_label=x_label, y_label=y_label, loc=0)
        return np.column_stack((unique_ret_times, total_intensities))


def specific_intensity_plot(fname, mz_list_to_plot, data_array_dict, num_decimals_ms_accuracy,
                            num_decimals_ret_time_accuracy, out_dir):
    """
    Plot total intensity versus retention times (combines retention times in this method; calls plotting function)
    :param fname: str, name of the file where the data originated
    :param data_array_dict: ndarray (n x 3) with M/Z, intensity, and retention times
    :param mz_list_to_plot: list, with up to 5 mz values to plot vs time on the same plot
    :param num_decimals_ms_accuracy: int, number of decimal points in MS accuracy, for rounding
    :param num_decimals_ret_time_accuracy: number of decimal points in retention time accuracy, for rounding
    :param out_dir: None or str, provides location where new file should be saved (None for current directory)
    :return: ndarray, (m x 2), were m is the number of unique retention times, in first column. Second column is
        total intensity for that retention time.
    """
    if len(mz_list_to_plot) > 5:
        raise InvalidDataError("The method specific_intensity_plot expects at most 5 mz values to display on one plot.")
    for ms_level, data_array in data_array_dict.items():
        # may need to round before this
        data_array[:, 0] = np.around(data_array[:, 0], num_decimals_ret_time_accuracy)
        x_val_dict = defaultdict()
        y_val_dict = defaultdict()
        curve_label = defaultdict()
        mz_counter = 0
        for mz_val in mz_list_to_plot:
            sub_data_array = data_array[data_array[:, 0] == 0]
            if len(sub_data_array) < 1:
                warning(f"No data found for MZ value {mz_val} in {ms_level} from {os.path.relpath(fname)}. This "
                        f"MZ will be omitted from the plot of MZ intensities versus retention time for this file and "
                        f"MS level.")
            else:
                curve_label[mz_counter] = f"{mz_val:.{num_decimals_ms_accuracy}f}"
                x_val_dict[mz_counter] = sub_data_array[:, 2]
                y_val_dict[mz_counter] = sub_data_array[:, 1]
                mz_counter += 1
        x_label = "Retention time (min)"
        y_label = "Intensity (unscaled)"
        suffix = "_int_v_time"
        if ms_level not in fname:
            suffix = suffix + "_" + ms_level
        plot_fname = create_out_fname(fname, suffix=suffix, ext='png', base_dir=out_dir)
        make_fig(plot_fname, x_array=x_val_dict[0], y1_array=y_val_dict[0], y1_label=y_val_dict[0],
                 x2_array=x_val_dict[1], y2_array=x_val_dict[1], y2_label=y_val_dict[1],
                 x3_array=x_val_dict[2], y3_array=x_val_dict[2], y3_label=y_val_dict[2],
                 x4_array=x_val_dict[3], y4_array=x_val_dict[3], y4_label=y_val_dict[3],
                 x5_array=x_val_dict[4], y5_array=x_val_dict[4], y5_label=y_val_dict[4],
                 x_label=x_label, y_label=y_label, loc=0)
        return x_val_dict, y_val_dict


def plot_direct_injection(fname, data_array_dict, out_dir):
    """
    Plot total intensity versus MZ values (assumes intensities from different retention points have been combined)
    :param fname: str, name of the file where the data originated
    :param data_array_dict: ndarray (n x 3) with M/Z, intensity, and retention times
    :param out_dir: None or str, provides location where new file should be saved (None for current directory)
    :return: ndarray, (m x 2), were m is the number of unique retention times, in first column. Second column is
        total intensity for that retention time.
    """
    for ms_level, data_array in data_array_dict.items():
        # may need to round before this
        x_array = data_array[:, 0]
        y_array = data_array[:, 1]
        x_label = "M/Z values"
        y_label = "Intensity (unscaled)"
        suffix = "_mz_v_intensity"
        plot_fname = create_out_fname(fname, suffix=suffix, ext='png', base_dir=out_dir)
        make_fig(plot_fname, x_array=x_array, y1_array=y_array,
                 x_label=x_label, y_label=y_label, loc=0)
