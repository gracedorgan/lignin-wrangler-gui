# -*- coding: utf-8 -*-

"""
structure_search.py
Methods called by ms2molecules to identify molecular structures
"""

import os
import re
import warnings
import numpy as np
import matplotlib.pyplot as plt
from rdkit import Chem
from common_wrangler.common import (create_out_fname, get_fname_root, warning, parse_stoich)
from lignin_wrangler.create_library import make_image_grid
from lignin_wrangler.lignin_common import (M_Z, FORMULA_SMI_DICT, INTENSITY, GRAPH_SUFFIX, MIN_ERR_FORMULA,
                                           MIN_ERR_DBE, MIN_ERR)

plt.style.use('seaborn-whitegrid')


def get_energy_levels(keys):
    """
    A helper method which goes through the keys of a dictionary and makes an array out of the number following "hcd"
    :param keys: a list of keys, all strs
    :return: a list of integers
    """
    energy_levels = []
    for fname in keys:
        base_name = get_fname_root(fname.lower())
        hcd_match = re.search(r'hcd(\d+)', base_name)
        if hcd_match:
            str_nrg = hcd_match.group(1)
        else:
            warning("a file used as a key in this dictionary did not end in 1 or 2 digits")
            str_nrg = ""
        energy_levels.append(int(str_nrg))
    return energy_levels


def make_dbe_mw_graphs(dbe_dict, mw_dict, out_dir=None):
    """
    makes and saves a graph of the bde value vs fragmentation energy for each set
    of qualifying files. the file the graph is saved to will be the fkey+_dbe_graph.png.
    :param mw_dict: a nested dictionary of fkeys to a dictionary of filenames and their
        associated weighted average molecular weights for all peaks
    :param dbe_dict: a nested dictionary of fkeys to a dictionary of filenames and their
        associated dbe values
    :param out_dir: none if default output location is to be used
    :return: nothing
    """
    for fkey in dbe_dict:
        out_filename = create_out_fname(fkey, suffix=GRAPH_SUFFIX, base_dir=out_dir, ext="png")
        fig = plt.figure()
        # The add_subplot sometimes throws a warning that we want to ignore
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            ax1 = fig.add_subplot(211)
            x = get_energy_levels(dbe_dict[fkey].keys())
            x2 = np.asarray(x)
            y = dbe_dict[fkey].values()
            dbes = []
            for dbe in y:
                dbes.append(float(dbe))
            y2 = np.asarray(dbes)
            ax1.plot(x2, y2, 'or-')
            ax1.set_title('DBE vs. Fragmentation Energy')
            ax1.set_xlabel('Fragmentation Energy')
            ax1.set_ylabel('Double Bond Equivalent')
            # now mw
            ax2 = fig.add_subplot(212)
        mw_y = mw_dict[fkey].values()
        mws = []
        for mw in mw_y:
            mws.append(float(mw))
        mw_y2 = np.asarray(mws)
        ax2.plot(x2, mw_y2, 'ob-')
        ax2.set_title('Weighted Average Molecular Weight vs. Fragmentation Energy')
        ax2.set_xlabel('Fragmentation Energy')
        ax2.set_ylabel('Weighted Average Molecular Weight')
        fig.tight_layout()
        fig.savefig(out_filename)
        print(f"Wrote file: {os.path.relpath(out_filename)}")
        plt.close()


def remove_impossible_formulas(long_output_list):
    """
    makes a list of formulas we have matched to peaks, but without the formulas that are not sub-formulas
    of the "root" formula, or the formula that is originally to be fragmented.
    :param long_output_list: a list of dictionaries for each peak in ms data
    :return: a list of dictionaries corresponding to the peaks of ms data without the formulas that are impossible
    to get from this fragmentation
    """
    new_list = []
    root = max(long_output_list, key=lambda x: x[M_Z])
    for peak_dict in long_output_list:
        if is_sub_formula(root[MIN_ERR_FORMULA], peak_dict[MIN_ERR_FORMULA]):
            new_list.append(peak_dict)
    return new_list


def is_sub_formula(formula, pot_sub_formula):
    """
    A small method that returns true if pot_sub_formula is a sub formula of formula. That means all elements
    in the subformula must also be in the formula, and there must be lesser or equal quantities of each
    element in the subformula.
    :param formula: the super-formula
    :param pot_sub_formula: the possible sub formula
    :return: True if second formula is a subformula of the first. False otherwise.
    """
    formula_dict = parse_stoich(formula)
    pot_sub_formula_dict = parse_stoich(pot_sub_formula)
    if len(pot_sub_formula_dict) > len(formula_dict):
        return False
    for key in pot_sub_formula_dict:
        if key not in formula_dict.keys():
            return False
    for key in formula_dict:
        if formula_dict[key] < pot_sub_formula_dict[key]:
            return False
    return True


def get_all_substructures(long_output_list):
    """
    This method takes in a long_output_list of dicts that represent formulas that
    are matched with molecular weights in the dataset. It will return a dictionary of dictionaries
    with all of the SMILE strings that qualify as substructures for each potential root.
    :param long_output_list: a list of dictionaries
    :return: a dict of dictionaries containing all of the substructure matches for all of
    the potential roots
    """
    new_list = remove_impossible_formulas(long_output_list)
    root = max(new_list, key=lambda x: x[M_Z])
    form = root[MIN_ERR_FORMULA].replace("*", "")
    all_substructures = {}
    for pot_root_smi in FORMULA_SMI_DICT[form]:
        temp_subs, temp_subs_mws = get_substructs(pot_root_smi, new_list, root[MIN_ERR_FORMULA])
        if len(temp_subs) > 0:
            all_substructures[pot_root_smi] = (temp_subs, temp_subs_mws)
    return all_substructures


def output_substructures(all_substructures, out_dir):
    for potential_root in all_substructures:
        filename = potential_root + "_SUBSTRUCTS"
        make_image_grid(filename, all_substructures[potential_root][0], labels=all_substructures[potential_root][1],
                        out_dir=out_dir)


# todo: rearrangements
def get_substructs(root_smi, list_dicts, root_form):
    """
    This method takes a SMILE string that we are using as the root_smi, and it gets
    the number of SMILE strings that are a substruct match
    :param root_smi: the SMILE string of the root we are checking
    :param list_dicts: a list of dictionaries representing compounds that match to MWs in the data
    :param root_form: original formula of the root we are checking
    :return: a list of SMILE strings which are substructs, and a list of the mws of each struct
    """
    substruct_matches = []
    substruct_mws = []
    root_mol = Chem.MolFromSmiles(root_smi)
    for match_dict in list_dicts:
        if match_dict[MIN_ERR_FORMULA] != root_form:
            sub_formula = match_dict[MIN_ERR_FORMULA].replace("*", "")
            sub_formula_mw = match_dict[M_Z]
            for smi in FORMULA_SMI_DICT[sub_formula]:
                sub_mol = Chem.MolFromSmiles(smi)
                if root_mol.HasSubstructMatch(sub_mol):
                    substruct_matches.append(smi)
                    substruct_mws.append(str(sub_formula_mw))
    return substruct_matches, substruct_mws


def make_fkey(fname):
    """
    This function creates a key that can be used in the dbe_dict, my removing the path and extension, keeps what
    remains as the key
    :param fname: a valid filename for ms data
    :return: a string without the original fnames' extension or HCD's trailing digits; blank string if no HCD+number hit
    """
    base_name = get_fname_root(fname.lower())
    hcd_match = re.search(r'hcd(\d+)', base_name)
    if hcd_match:
        # hcd_match.group(1) to get number only, but that can cause problems with the splitting
        # (e.g. 0 may show up elsewhere, too) so adding hcd back with the join
        matched_text = hcd_match.group(0)
        str_list = base_name.split(matched_text)
        return "hcd".join(str_list)
    else:
        return ""


def get_dbe_weighted_average(long_output_list, max_error):
    """
    calculates the weighted average dbe for all peaks in the long_output_list
    :param long_output_list: a list of dictionaries for every peak in the data
    :param max_error: maximum error (in ppm) for the M/Z to be considered matched
    :return: the weighted average dbe calculation for the top 5 peaks in this file
    """
    intensity_list = []
    dbe_list = []
    for t_dict in long_output_list:
        if t_dict[MIN_ERR] < max_error:
            intensity_list.append(t_dict[INTENSITY])
            dbe_list.append(t_dict[MIN_ERR_DBE])
    return np.average(dbe_list, weights=intensity_list)


def get_mw_weighted_average(mz_array):
    """
    calculates the weighted average mw for all peaks in the long_output_list
    :param mz_array: the array of all peaks above the threshold
    :return: the weighted average dbe calculation for the top 5 peaks in this file
    """
    return np.average(mz_array[:, 0], weights=mz_array[:, 1])


def make_dbe_mw_dict(fname, dbe_dict, mw_dict, long_output_list, mz_data_array, max_error):
    """
    goes through a list of files and creates the dbe_dict and a similar mw dict.
    # mol. weight weighted average of ALL peaks/energy to frag energy
    # all matches dbe weighted average/energy
    dbe_dict, mw_dict
    :param fname: file name to process
    :param dbe_dict: a dictionary mapping "fkeys" to a dictionary or file names to dbe values
    :param mw_dict: a dictionary mapping "fkeys" to a dictionary or file names to averaged mw values
    :param long_output_list: dictionary of calculated values from fname
    :param mz_data_array: ndarray of data from fname
    :param max_error: float, in ppm max error to consider a match
    :return: n/a, updates dbe_dict and mw_dict
    """
    fkey = make_fkey(fname)
    # making sure f key exists
    if not fkey:
        return

    # get the weighted average to eventually make the dbe graph
    # it is possible that there are no matches--we'll catch that error
    try:
        dbe_weighted_average = get_dbe_weighted_average(long_output_list, max_error)
        # insert the weighted average to correspond with the correct file name in the dbe_dict
        dbe_dict[fkey][fname] = dbe_weighted_average
    except ZeroDivisionError:
        warning(f"There were no formula matches within the specified tolerance of {max_error} ppm for file: {fname}\n"
                f"    The program will continue without calculating a weighted-average DBE value from this file.")
        dbe_dict[fkey][fname] = np.nan

    # get the weighted average to eventually make the mw graph
    mw_weighted_average = get_mw_weighted_average(mz_data_array)
    # insert the weighted average to correspond with the correct file name in the dbe_dict
    mw_dict[fkey][fname] = mw_weighted_average
