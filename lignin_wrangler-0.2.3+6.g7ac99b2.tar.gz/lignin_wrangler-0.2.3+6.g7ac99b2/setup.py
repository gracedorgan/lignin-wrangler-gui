# -*- coding: utf-8 -*-
"""
Performs a variety of operations for modeling lignin, from radical coupling (synthesis, after transport to the cell
wall) to analyzing MS output to aid in structure determination.
"""
from setuptools import setup
import versioneer

DOCLINES = __doc__.split("\n")

setup(
    # Self-descriptive entries which should always be present
    name='lignin_wrangler',
    author='Heather B Mayes',
    author_email='heather.mayes@nrel.gov',
    # url='http://www.my_package.com',  # Website
    description=DOCLINES[0],
    long_description="\n".join(DOCLINES[2:]),
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    license='MIT',

    # Which Python importable modules should be included when your package is installed
    packages=['lignin_wrangler'],

    # Optional include package data to ship with your package
    # Comment out this line to prevent the files from being packaged with your software
    # Extend/modify the list to include/exclude other items as need be
    package_data={'lignin_wrangler': ["data/*.dat"]
                  },

    entry_points={'console_scripts': ['create_library = lignin_wrangler.create_library:main',
                                      'ms2molecules = lignin_wrangler.ms2molecules:main',
                                      'syn_lignin = ligninkmc.syn_lignin:main',
                                      ],
                  },     package_dir={'lignin_wrangler': 'lignin_wrangler'},

    test_suite='tests',
    # Additional entries you may want simply uncomment the lines you want and fill in the data
    platforms=['Linux',
               'Mac OS-X',
               'Unix',
               'Windows'],            # Valid platforms your code works on, adjust to your flavor
    python_requires=">=3.5",  # Python version restrictions

    # Required packages, pulls from pip if needed; do not use for Conda deployment
    # rdkit must be specially installed: use `conda install -c conda-forge rdkit`
    install_requires=['numpy', 'common-wrangler>=0.2.6', 'pymzml', 'matplotlib', 'networkx', 'scipy'],

    # Manual control if final package is compressible or not, set False to prevent the .egg from being made
    # zip_safe=False,

)
